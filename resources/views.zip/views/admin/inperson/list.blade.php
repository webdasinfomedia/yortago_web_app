@extends('admin.layouts.master')
@section('admin_title')
In Person Contact
@endsection

@section('css')

<link href="{{ URL::to('front/dashboard/vendor/datatables/css/jquery.dataTables.min.css') }}" rel="stylesheet">

<link href="{{ URL::to('front/dashboard//vendor/summernote/summernote.css') }}" rel="stylesheet">


@endsection


@section('content')

    <div class="container-fluid">
        <div class="page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">DashBoard</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">In Person Contact</a></li>
            </ol>
        </div>
        <!-- row -->


        <div class="row">

            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">In Person </h4>

                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example3" class="display min-w850">
                                <thead>
                                    <tr>
                                        <th>Sr No</th>
                                        <th>User Name</th>
                                        <th>User Email</th>
                                        <th>User Mobile</th>
                                        <th>User Message</th>
                                        <th>Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($lists as $list)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $list->name }}</td>
                                        <td>{{ $list->email }}</td>
                                        <td>{{ $list->mobile_no }}</td>
                                        <td>{{ $list->message }}</td>
                                        <td> <a href="#" onclick="edit(`{{ $list['id'] }}`,`{{ $list['email'] }}`)" class="btn btn-primary shadow btn-xs sharp mr-1"><i class="fa fa-envelope"></i></a></td>

                                    </tr>
                                    @endforeach


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

    </div>

    <div class="modal fade" id="editModal">
        <div class="modal-dialog modal-lg " role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Reply Email</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                    </button>
                </div>
                <form method="POST" action="{{ route('admin.in.person.reply') }}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="email"  id="email">
                    <input type="hidden" name="id"  id="id">
                <div class="modal-body">
                    <div class="form-row">
                    <div class="form-group col-md-12">
                        <label>Subject</label>
                        <input type="text" class="form-control" name="subject" required placeholder="Subject ...">
                        @if ($errors->has('subject'))
                        <span class="invalid-feedback" role="alert" style="display: block">
                                        <strong>{{ $errors->first('subject') }}</strong>
                                    </span>
                          @endif
                    </div>
                    <div class="form-group col-md-12">
                        <label>Subject</label>
                        <textarea type="text" class="summernote" required name="content" placeholder="Suggestion ....." id=""></textarea>
                        @if ($errors->has('content'))
                        <span class="invalid-feedback" role="alert" style="display: block">
                                        <strong>{{ $errors->first('content') }}</strong>
                                    </span>
                          @endif
                    </div>



                </div>
            </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Send Mail</button>
                </div>
                </form>
            </div>
        </div>
    </div>

@endsection


@section('script')

<script src="{{ URL::to('front/dashboard/vendor/datatables/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ URL::to('front/dashboard/js/plugins-init/datatables.init.js') }}"></script>
<script src="{{ URL::to('front/dashboard/vendor/summernote/js/summernote.min.js') }}"></script>

<script>
    function edit(id,email){
        $('#id').val(id);
        $('#email').val(email);

        $('#editModal').modal();
    }
    $('.summernote').summernote({
        placeholder: 'Mail Content',
        tabsize: 2,
        height: 100,

      });
</script>

@endsection


