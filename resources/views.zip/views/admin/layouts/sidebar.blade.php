<div class="deznav">
    <div class="deznav-scroll">
        <ul class="metismenu" id="menu">
            <li><a class="ai-icon" href="{{ route('admin.dashboard') }}" aria-expanded="false">
                    <i class="flaticon-381-networking"></i>
                    <span class="nav-text">Dashboard</span>
                </a>

            </li>
            <li><a class="ai-icon" href="{{ route('admin.streaming.list') }}" aria-expanded="false">
                <i class="la la-tasks"></i>
                <span class="nav-text">Stream Plan</span>
            </a>
            </li>
            <li><a class="ai-icon" href="{{ route('admin.live.streaming.list') }}" aria-expanded="false">
                <i class="flaticon-381-television"></i>
                <span class="nav-text">Live Stream</span>
            </a>
            </li>
            <li><a class="ai-icon" href="{{ route('admin.exercise.program.list') }}" aria-expanded="false">
                <i class="la la-dumbbell"></i>
                <span class="nav-text">Exercise Program</span>
            </a>
            </li>
            <li><a class="ai-icon" href="{{ route('admin.nutrition.program.list') }}" aria-expanded="false">
                <i class="flaticon-381-controls-3"></i>
                <span class="nav-text">Nutrition Program</span>
            </a>
            </li>
            <li><a class="ai-icon" href="{{ route('admin.online.training.plan.list') }}" aria-expanded="false">
                <i class="la la-dollar"></i>
                <span class="nav-text">Online Training Plan</span>
            </a>
            </li>


            <li><a class="ai-icon" href="{{ route('admin.testimonial.list') }}" aria-expanded="false">
                <i class="la la-quote-left"></i>
                <span class="nav-text">Testimonial</span>
            </a>
            <li><a class="ai-icon" href="{{ route('admin.users.list') }}" aria-expanded="false">
                <i class="la la-users"></i>
                <span class="nav-text">End User/Athlete</span>
            </a>

        </li>
            <li><a class="ai-icon" href="{{ route('admin.live-stream.users.list') }}" aria-expanded="false">
                    <i class="la la-users"></i>
                    <span class="nav-text">Live Stream Users</span>
                </a>

            </li>
            <li><a class="ai-icon" href="{{ route('admin.newsletter.list') }}" aria-expanded="false">
                <i class="la la-envelope"></i>
                <span class="nav-text">NewsLetter</span>
            </a>

        </li>
            <li><a class="ai-icon" href="{{ route('admin.in.person.list') }}" aria-expanded="false">
                <i class="la la-user"></i>
                <span class="nav-text">In Person Contact</span>
            </a>

        </li>
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-381-settings-2"></i>
                    <span class="nav-text">CMS</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="{{ route('admin.cms.about') }}">About</a></li>
                    <li><a href="{{ route('admin.cms.term') }}">Term Condition</a></li>
                    <li><a href="{{ route('admin.cms.privacy') }}">Privacy Policy</a></li>
                    <li><a href="{{ route('admin.cms.slider') }}">Home Slider</a></li>
                    <li><a href="{{ route('admin.cms.site.config') }}">Site Configuration</a></li>
                    <li><a href="{{ route('admin.cms.age.list') }}">Focus</a></li>
                    <li><a href="{{ route('admin.cms.equipment.list') }}">Equipment</a></li>
                    <li><a href="{{ route('admin.cms.experience.level.list') }}">Experience Level</a></li>

                </ul>

            </li>


        </ul>

    </div>
</div>
