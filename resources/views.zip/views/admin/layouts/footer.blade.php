<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="https://deviotech.com/" target="_blank">Devio Tech</a> 2021</p>
    </div>
</div>
