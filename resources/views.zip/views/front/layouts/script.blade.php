<script src="{{ URL::to('front/js/jquery-3.3.1.min.js') }}"></script>
<script src="{{ URL::to('front/js/bootstrap.min.js') }}"></script>
<script src="{{ URL::to('front/js/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ URL::to('front/js/mixitup.min.js') }}"></script>
<script src="{{ URL::to('front/js/jquery.slicknav.js') }}"></script>
<script src="{{ URL::to('front/js/owl.carousel.min.js') }}"></script>
<script src="{{ URL::to('front/js/main.js') }}"></script>
<script src="{{ URL::to('front/dashboard/vendor/sweetalert2/dist/sweetalert2.min.js') }}"></script>

@yield('script')

<script>

    $(window).on('load', function () {

   @if(session('message'))
   swal("Subscribed Successfully", "{{ session('message') }}", "success");

    @elseif(session('error'))
    swal("Error!", "{{ session('error') }}", "error");
    @endif
});
</script>
