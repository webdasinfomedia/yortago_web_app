<!DOCTYPE html>
<html lang="zxx">

@include('front.layouts.head')

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header Section Begin -->
  @include('front.layouts.header')
    <!-- Header End -->



  @yield('content')


  {{-- <a href="" class="c-btn c-fill-color-btn float" style="padding: 10px 18px;">Submit Request</a> --}}




    <!-- Footer Section Begin -->
  @include('front.layouts.footer')
    <!-- Footer Section End -->


    @include('front.layouts.script')

</body>

</html>
