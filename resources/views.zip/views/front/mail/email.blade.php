<!DOCTYPE html>
<html>
<head>
    <title>Yortago</title>
</head>
<body>
    <h1>


        {!! $details['content'] !!}


</body>
</html>
